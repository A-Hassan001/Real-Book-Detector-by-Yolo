import json
import requests
import os


class BookCollector:

    def __init__(self, api_url, file_path):
        self.API_URL = api_url
        self.FILE_PATH = file_path
        self.cookies = {
        'csrftoken': 'dSBTsfNButvTqPaqUOc4Dv80y08pHLpt',
        'sessionid': 'i7n5yrllx3m4nwq3s60vbsk2wcq6l38k',
    }
        self.headers = {
        'accept': '*/*',
        'accept-language': 'en-US,en;q=0.9',
        'priority': 'u=1, i',
        'referer': 'https://booksdashboard-production.up.railway.app/api/dashboard/',
        'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
        # 'cookie': 'csrftoken=dSBTsfNButvTqPaqUOc4Dv80y08pHLpt; sessionid=i7n5yrllx3m4nwq3s60vbsk2wcq6l38k',
    }

    # Fetch API Data
    def fetch_data(self):
        response = requests.get(self.API_URL, cookies=self.cookies, headers=self.headers)
        print("Status Code:", response.status_code)

        if "application/json" not in response.headers.get("Content-Type", ""):
            print("⚠️ Response is not JSON")
            return []

        return response.json()

    # Extract required fields
    def process_data(self, data_list):
        results_list = []

        for data in data_list:
            results = data.get("results", [])

            for result in results:
                book_url = result.get("url", "")

                if "vinted" in book_url:
                    results_list.append({
                        "book_url": book_url,
                        "image_url": result.get("image", "")
                    })

        return results_list

    # Read existing file
    def read_existing_data(self):
        if not os.path.exists(self.FILE_PATH):
            print("No existing file found. Creating new one.")
            return []

        try:
            with open(self.FILE_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print("File read error:", e)
            return []

    # Save only unique records
    def save_unique_data(self, new_data):
        existing_data = self.read_existing_data()

        existing_urls = set(item["book_url"] for item in existing_data)

        unique_data = []
        for item in new_data:
            if item["book_url"] not in existing_urls:
                unique_data.append(item)

        final_data = existing_data + unique_data

        with open(self.FILE_PATH, "w", encoding="utf-8") as f:
            json.dump(final_data, f, indent=4, ensure_ascii=False)

        print("New records added:", len(unique_data))
        print("Total records saved:", len(final_data))

        return unique_data  # ✅ IMPORTANT

    # Main runner
    def run(self):
        print("🚀 Script Started")

        data_list = self.fetch_data()

        if not data_list:
            print("No data received from API")
            return []

        processed_data = self.process_data(data_list)

        print("Fetched records:", len(processed_data))

        new_data = self.save_unique_data(processed_data)

        return new_data  # ✅ ONLY NEW BOOKS


# Run script
if __name__ == "__main__":
    FILE_PATH = "source/books_output.json"
    API_URL = "https://booksdashboard-production.up.railway.app/api/all_filtered_results/?min_price=0&max_price=2000&group_by=isbn"

    collector = BookCollector(API_URL, FILE_PATH)
    collector.run()